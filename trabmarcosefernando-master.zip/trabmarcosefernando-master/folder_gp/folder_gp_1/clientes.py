'''
* Simulação de uma tabela de clientes
* id : usuario
'''

clientes = {
  1: {
    'email': 'jose.contato@gmail.com',
    'nome': 'Jose',
    'telefone': '963254040'
  },
  2: {
    'email': 'maria.contato@gmail.com',
    'nome': 'Maria',
    'telefone': '963304040'
  },
  3: {
    'email': 'vitor.contato@gmail.com',
    'nome': 'Vitor',
    'telefone': '963251040'
  },
  4: {
    'email': 'olavo.contato@gmail.com',
    'nome': 'Olavo',
    'telefone': '963896040'
  },
  5: {
    'email': 'carla.contato@gmail.com',
    'nome': 'Carla',
    'telefone': '998096040'
  },
}