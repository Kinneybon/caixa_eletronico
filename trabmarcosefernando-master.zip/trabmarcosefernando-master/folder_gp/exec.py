from folder_gp_1.Main import Proj

if __name__ == '__main__':
  main = Proj()
  main.init()
  pass

